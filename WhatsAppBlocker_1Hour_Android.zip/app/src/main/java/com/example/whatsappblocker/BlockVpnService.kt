package com.example.whatsappblocker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.util.concurrent.atomic.AtomicBoolean

class BlockVpnService : VpnService() {

    companion object {
        const val ACTION_START = "START"
        private const val CHANNEL_ID = "whatsapp_blocker"
        private const val NOTIFICATION_ID = 100
        private const val BLOCK_TIME_MS = 60L * 60L * 1000L

        @Volatile
        var isRunning: Boolean = false
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private val stopping = AtomicBoolean(false)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            startForeground(NOTIFICATION_ID, notification("WhatsApp blocked — 1 hour"))
            startVpn()
        }
        return START_NOT_STICKY
    }

    private fun startVpn() {
        if (isRunning) return

        stopping.set(false)

        try {
            val builder = Builder()
                .setSession("WhatsApp Blocker")
                .setMtu(1500)
                .addAddress("10.8.0.2", 32)
                .addRoute("0.0.0.0", 0)

            // Only WhatsApp is placed inside this VPN.
            // Packets entering the VPN are discarded below.
            builder.addAllowedApplication("com.whatsapp")

            vpnInterface = builder.establish()

            if (vpnInterface == null) {
                stopSelf()
                return
            }

            isRunning = true

            worker = Thread {
                val pfd = vpnInterface ?: return@Thread
                try {
                    FileInputStream(pfd.fileDescriptor).use { input ->
                        val buffer = ByteArray(32767)
                        while (!stopping.get()) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            // Deliberately do not write packets back.
                            // This drops WhatsApp traffic.
                        }
                    }
                } catch (_: Exception) {
                    // VPN stopped or interface closed.
                }
            }.also { it.start() }

            Thread {
                try {
                    Thread.sleep(BLOCK_TIME_MS)
                } catch (_: InterruptedException) {
                    return@Thread
                }
                stopVpn()
            }.start()

        } catch (_: Exception) {
            stopVpn()
        }
    }

    private fun stopVpn() {
        stopping.set(true)
        isRunning = false

        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }

        vpnInterface = null
        worker?.interrupt()
        worker = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? {
        return super.onBind(intent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "WhatsApp Blocker",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    private fun notification(text: String): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("WhatsApp Blocker")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("WhatsApp Blocker")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setOngoing(true)
                .build()
        }
    }
}
