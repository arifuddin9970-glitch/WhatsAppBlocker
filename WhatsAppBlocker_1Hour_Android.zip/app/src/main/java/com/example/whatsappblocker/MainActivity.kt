package com.example.whatsappblocker

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {

    companion object {
        private const val VPN_REQUEST = 1001
    }

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)

        findViewById<Button>(R.id.startButton).setOnClickListener {
            val intent = VpnService.prepare(this)
            if (intent != null) {
                startActivityForResult(intent, VPN_REQUEST)
            } else {
                startBlocking()
            }
        }

        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, BlockVpnService::class.java))
            statusText.text = "Status: Not blocked"
        }

        updateStatus()
    }

    private fun startBlocking() {
        val intent = Intent(this, BlockVpnService::class.java)
        intent.action = BlockVpnService.ACTION_START
        startForegroundService(intent)
        statusText.text = "Status: WhatsApp blocked for 1 hour"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST && resultCode == RESULT_OK) {
            startBlocking()
        } else if (requestCode == VPN_REQUEST) {
            statusText.text = "VPN permission was not granted"
        }
    }

    private fun updateStatus() {
        if (BlockVpnService.isRunning) {
            statusText.text = "Status: WhatsApp blocked"
        }
    }
}
