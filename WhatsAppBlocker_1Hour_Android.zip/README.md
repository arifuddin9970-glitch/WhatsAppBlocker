# WhatsApp Blocker — 1 Hour

This Android project uses Android VpnService to route only the WhatsApp package
(com.whatsapp) through a local VPN interface. Packets entering the VPN are
discarded, so WhatsApp loses network access while other applications remain
outside the VPN.

## Build on Android phone

1. Install AndroidIDE or another Android Gradle IDE.
2. Extract/import this ZIP as a Gradle Android project.
3. Allow the IDE to download Gradle/Android dependencies.
4. Build the `app` module and install the generated APK.
5. Open the app.
6. Tap "BLOCK WHATSAPP FOR 1 HOUR".
7. Accept Android's VPN permission dialog.
8. WhatsApp should have no network access for approximately one hour.
9. Tap "STOP BLOCKING" to end it early.

## Important limitations

- This version targets the standard WhatsApp package `com.whatsapp`.
- It is a local VPN firewall technique; Android can show a VPN/key icon.
- Only one VPN can normally be active at a time. If another VPN is running,
  stop it before using this app.
- Android battery/background management can vary by phone manufacturer.
- This is a simple first version; it does not yet have an app picker,
  custom durations, schedules, or a persistent timer display.
